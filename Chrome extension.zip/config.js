// Centralized backend configuration
const PV_CONFIG = {
  API_UPLOAD_URL: "http://proofvault.net:3003/api/pdf/upload",
  API_HEALTH_URL: "http://proofvault.net:3003/api/health"
};